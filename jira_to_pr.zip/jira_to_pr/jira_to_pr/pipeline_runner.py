from __future__ import annotations

"""End-to-end driver implementing the two human gates.

Usage (programmatic):
    import asyncio
    from jira_to_pr.pipeline_runner import run_pipeline
    asyncio.run(run_pipeline("PROJ-123", "<ticket text>"))

The two gates:
  1. After Spec: if the spec agent emits NEEDS_CLARIFICATION, we stop and return
     the questions. The caller collects human answers and calls
     `resume_after_clarification`.
  2. After PR draft: the pipeline stops with a PR description for a human to
     review and merge. We never merge automatically.
"""

import logging
from dataclasses import dataclass
from typing import Optional

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from jira_to_pr.agents.pipeline import build_build_root, build_spec_root
from jira_to_pr.config.settings import get_settings

logger = logging.getLogger("jira_to_pr")

CLARIFICATION_TOKEN = "NEEDS_CLARIFICATION:"


@dataclass
class PipelineResult:
    """Outcome of a pipeline run."""

    status: str  # "needs_clarification" | "completed" | "error"
    spec: Optional[str] = None
    clarification_questions: Optional[str] = None
    pr_draft: Optional[str] = None
    session_id: Optional[str] = None


async def _drain(runner: Runner, *, user_id: str, session_id: str, text: str) -> str:
    """Run an agent to completion, returning the final response text."""
    message = types.Content(role="user", parts=[types.Part(text=text)])
    final_text = ""
    async for event in runner.run_async(
        user_id=user_id, session_id=session_id, new_message=message
    ):
        if event.is_final_response() and event.content and event.content.parts:
            final_text = event.content.parts[0].text or ""
        # Log tool activity for observability in the terminal.
        if event.get_function_calls():
            for call in event.get_function_calls():
                logger.info("tool_call: %s(%s)", call.name, call.args)
    return final_text


async def run_pipeline(
    ticket_id: str,
    ticket_text: str,
    *,
    user_id: str = "developer",
) -> PipelineResult:
    """Run Spec (Run 1). Pauses at the clarification gate if needed; otherwise
    proceeds straight into the build pipeline (Run 2)."""
    settings = get_settings()
    session_service = InMemorySessionService()
    session_id = f"ticket-{ticket_id}"

    await session_service.create_session(
        app_name=settings.app_name,
        user_id=user_id,
        session_id=session_id,
        state={"jira_ticket": ticket_text, "ticket_id": ticket_id},
    )

    # --- Run 1: Spec --------------------------------------------------------
    spec_runner = Runner(
        agent=build_spec_root(),
        app_name=settings.app_name,
        session_service=session_service,
    )
    spec_text = await _drain(
        spec_runner, user_id=user_id, session_id=session_id,
        text="Specify this ticket.",
    )

    if spec_text.strip().startswith(CLARIFICATION_TOKEN):
        logger.info("Clarification required for %s", ticket_id)
        return PipelineResult(
            status="needs_clarification",
            clarification_questions=spec_text,
            session_id=session_id,
        )

    # No clarification needed -> continue into the build pipeline immediately.
    return await _run_build(session_service, session_id, user_id, spec_text)


async def resume_after_clarification(
    session_id: str,
    answers: str,
    *,
    ticket_text: str,
    ticket_id: str,
    user_id: str = "developer",
) -> PipelineResult:
    """After a human answers clarification questions, re-spec with the answers
    injected, then run the build pipeline.

    Note: with InMemorySessionService, state does not survive process restarts.
    For a real deployment swap in a persistent SessionService (see README) and
    you can resume the existing session_id instead of recreating it.
    """
    settings = get_settings()
    session_service = InMemorySessionService()
    await session_service.create_session(
        app_name=settings.app_name,
        user_id=user_id,
        session_id=session_id,
        state={
            "jira_ticket": ticket_text,
            "ticket_id": ticket_id,
            "clarification_answers": answers,
        },
    )

    spec_runner = Runner(
        agent=build_spec_root(),
        app_name=settings.app_name,
        session_service=session_service,
    )
    spec_text = await _drain(
        spec_runner, user_id=user_id, session_id=session_id,
        text="Re-specify with the clarification answers.",
    )
    return await _run_build(session_service, session_id, user_id, spec_text)


async def _run_build(
    session_service: InMemorySessionService,
    session_id: str,
    user_id: str,
    spec_text: str,
) -> PipelineResult:
    """Run 2: the full build pipeline, stopping at the PR (human merge) gate."""
    settings = get_settings()
    build_runner = Runner(
        agent=build_build_root(),
        app_name=settings.app_name,
        session_service=session_service,
    )
    pr_draft = await _drain(
        build_runner, user_id=user_id, session_id=session_id,
        text="Build this ticket end to end and produce a PR draft.",
    )
    logger.info("Pipeline complete for session %s; awaiting human merge.", session_id)
    return PipelineResult(
        status="completed",
        spec=spec_text,
        pr_draft=pr_draft,
        session_id=session_id,
    )
