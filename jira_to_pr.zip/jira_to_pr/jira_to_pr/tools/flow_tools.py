from __future__ import annotations

"""Control-flow tools that let agents steer the workflow.

`exit_loop` is the canonical ADK pattern for terminating a LoopAgent early:
the checker agent calls it (setting escalate=True) once quality is acceptable,
otherwise the loop runs until max_iterations.
"""

from google.adk.tools.tool_context import ToolContext


def exit_loop(tool_context: ToolContext) -> dict:
    """Signal that the current loop's quality bar is met and it should stop.

    Call this ONLY when every check has passed. Sets the escalate action that
    a LoopAgent uses as its termination condition.
    """
    tool_context.actions.escalate = True
    return {"status": "exiting_loop", "reason": "quality bar met"}


def record_blocker(tool_context: ToolContext, stage: str, summary: str) -> dict:
    """Record a blocking finding (from review/security/performance) into shared
    state so the quality gate can decide whether to loop back to Dev.

    Args:
        stage: which stage raised it (e.g. "security").
        summary: short description of the blocker.
    """
    blockers = tool_context.state.get("open_blockers", [])
    blockers.append({"stage": stage, "summary": summary})
    tool_context.state["open_blockers"] = blockers
    return {"recorded": True, "open_blocker_count": len(blockers)}


def clear_blockers(tool_context: ToolContext) -> dict:
    """Clear recorded blockers (Dev calls this after addressing them)."""
    tool_context.state["open_blockers"] = []
    return {"cleared": True}
