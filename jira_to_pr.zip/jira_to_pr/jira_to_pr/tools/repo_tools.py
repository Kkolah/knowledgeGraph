from __future__ import annotations

"""Repository tools exposed to agents.

Design principles:
  * Every path is resolved against the configured target repo and validated to
    stay inside it (no path traversal, no absolute escapes).
  * Tools return plain dicts (ADK serializes these into the model context).
  * Writes are restricted to an allowlist of extensions.
  * `run_checks` runs project commands (lint/test) inside the repo only.

These tools are what let Design/Dev/QA ground themselves in the ACTUAL repo
instead of hallucinating an architecture.
"""

import subprocess
from pathlib import Path

from google.adk.tools.tool_context import ToolContext

from jira_to_pr.config.settings import get_settings


def _safe_path(relative_path: str) -> Path:
    """Resolve a path inside the target repo, rejecting traversal escapes."""
    settings = get_settings()
    root = settings.target_repo_path.resolve()
    candidate = (root / relative_path).resolve()
    if root not in candidate.parents and candidate != root:
        raise ValueError(
            f"Refusing to access '{relative_path}': outside the target repo."
        )
    return candidate


def read_repo_conventions(tool_context: ToolContext) -> dict:
    """Read the target repo's living conventions doc (architecture, logging,
    naming, testing). Call this BEFORE designing or writing code.

    Returns:
        A dict with the conventions text, or an error message if missing.
    """
    settings = get_settings()
    path = settings.conventions_path
    if not path.exists():
        return {
            "found": False,
            "message": (
                f"No conventions file at {path}. Proceed using widely accepted "
                "best practices for the detected language/framework, and note "
                "in your output that conventions were inferred."
            ),
        }
    return {"found": True, "path": str(path), "conventions": path.read_text()}


def list_repo_files(tool_context: ToolContext, subdirectory: str = ".") -> dict:
    """List files under a subdirectory of the target repo (recursive, capped).

    Args:
        subdirectory: Path relative to the repo root. Defaults to the root.

    Returns:
        A dict with a sorted list of relative file paths.
    """
    base = _safe_path(subdirectory)
    if not base.exists():
        return {"exists": False, "files": [], "message": f"{subdirectory} not found."}
    root = get_settings().target_repo_path.resolve()
    skip = {".git", "node_modules", "__pycache__", ".venv", "dist", "build"}
    files: list[str] = []
    for p in base.rglob("*"):
        if p.is_file() and not any(part in skip for part in p.parts):
            files.append(str(p.relative_to(root)))
        if len(files) >= 500:  # guard against huge repos blowing context
            break
    return {"exists": True, "count": len(files), "files": sorted(files)}


def read_repo_file(tool_context: ToolContext, relative_path: str) -> dict:
    """Read a source file from the target repo so you can pattern-match against
    existing code (imports, logging style, structure).

    Args:
        relative_path: File path relative to the repo root.
    """
    path = _safe_path(relative_path)
    if not path.exists() or not path.is_file():
        return {"found": False, "message": f"{relative_path} does not exist."}
    text = path.read_text(errors="replace")
    truncated = len(text) > 60_000
    return {
        "found": True,
        "path": relative_path,
        "content": text[:60_000],
        "truncated": truncated,
    }


def write_repo_file(tool_context: ToolContext, relative_path: str, content: str) -> dict:
    """Create or overwrite a file in the target repo. Restricted to allowed
    extensions and confined to the repo. Use only in Dev/Refactor/Docs stages.

    Args:
        relative_path: Destination path relative to the repo root.
        content: Full file contents to write.
    """
    settings = get_settings()
    path = _safe_path(relative_path)
    if path.suffix not in settings.writable_extensions:
        return {
            "written": False,
            "message": (
                f"Extension '{path.suffix}' is not writable. Allowed: "
                f"{', '.join(settings.writable_extensions)}"
            ),
        }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)

    # Track every file we touch in session state for the PR summary.
    touched = tool_context.state.get("touched_files", [])
    if relative_path not in touched:
        touched.append(relative_path)
    tool_context.state["touched_files"] = touched

    return {"written": True, "path": relative_path, "bytes": len(content)}


def run_checks(tool_context: ToolContext, command: str) -> dict:
    """Run a shell command (lint, build, or test) inside the target repo and
    return its output. Use to verify code compiles and tests pass.

    Args:
        command: e.g. "pytest -q", "npm test", "ruff check .".
    """
    settings = get_settings()
    root = settings.target_repo_path.resolve()
    try:
        proc = subprocess.run(
            command,
            shell=True,
            cwd=root,
            capture_output=True,
            text=True,
            timeout=600,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "exit_code": -1, "stdout": "", "stderr": "Timed out after 600s."}
    return {
        "ok": proc.returncode == 0,
        "exit_code": proc.returncode,
        "stdout": proc.stdout[-8_000:],
        "stderr": proc.stderr[-8_000:],
    }
