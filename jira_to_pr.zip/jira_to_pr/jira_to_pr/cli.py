from __future__ import annotations

"""Command-line entrypoint.

Examples:
    # From a ticket file
    python -m jira_to_pr.cli --ticket-id PROJ-123 --ticket-file ticket.md

    # Inline text
    python -m jira_to_pr.cli --ticket-id PROJ-123 --ticket "As a user I want..."

If the spec agent asks clarification questions, they are printed and the program
exits; re-run with --answers-file to resume.
"""

import argparse
import asyncio
import logging
import sys
from pathlib import Path

from jira_to_pr.pipeline_runner import (
    resume_after_clarification,
    run_pipeline,
)


def _read(path: str | None, inline: str | None) -> str:
    if inline:
        return inline
    if path:
        return Path(path).read_text()
    raise SystemExit("Provide --ticket or --ticket-file.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Jira-to-PR agent pipeline.")
    parser.add_argument("--ticket-id", required=True)
    parser.add_argument("--ticket")
    parser.add_argument("--ticket-file")
    parser.add_argument(
        "--answers-file",
        help="Path to clarification answers to resume a paused ticket.",
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    ticket_text = _read(args.ticket_file, args.ticket)

    if args.answers_file:
        answers = Path(args.answers_file).read_text()
        result = asyncio.run(
            resume_after_clarification(
                session_id=f"ticket-{args.ticket_id}",
                answers=answers,
                ticket_text=ticket_text,
                ticket_id=args.ticket_id,
            )
        )
    else:
        result = asyncio.run(run_pipeline(args.ticket_id, ticket_text))

    print("\n" + "=" * 70)
    print(f"STATUS: {result.status}")
    print("=" * 70)
    if result.status == "needs_clarification":
        print("\nThe pipeline needs answers before proceeding:\n")
        print(result.clarification_questions)
        print(
            "\nAnswer these in a file and re-run with "
            "--answers-file <path> to continue."
        )
        return 2
    if result.status == "completed":
        print("\n--- SPEC ---\n")
        print(result.spec)
        print("\n--- PR DRAFT (awaiting human review & merge) ---\n")
        print(result.pr_draft)
        return 0
    print("Pipeline error.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
