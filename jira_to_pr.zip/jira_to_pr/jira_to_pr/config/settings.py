from __future__ import annotations

"""Centralized, environment-driven configuration for the pipeline.

All tunable values live here so nothing is hard-coded inside agents. Values are
read from environment variables (or a .env file) with sensible defaults.
"""

import os
from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime configuration for the Jira-to-PR pipeline."""

    model_config = SettingsConfigDict(
        env_prefix="J2PR_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Model -------------------------------------------------------------
    model: str = Field(
        default="gemini-2.5-flash",
        description="LLM used by every LlmAgent unless overridden.",
    )

    # --- Application identity ---------------------------------------------
    app_name: str = Field(default="jira_to_pr")

    # --- Target repository -------------------------------------------------
    # The repository the Jira ticket modifies. Agents read conventions and
    # source from here; this is NOT the pipeline's own repo.
    target_repo_path: Path = Field(
        default=Path("./target_repo"),
        description="Filesystem path to the repo being modified.",
    )
    conventions_filename: str = Field(
        default="AGENTS.md",
        description="Name of the conventions doc inside the target repo.",
    )

    # --- Loop governors ----------------------------------------------------
    dev_qa_max_iterations: int = Field(default=3, ge=1, le=10)
    refactor_qa_max_iterations: int = Field(default=2, ge=1, le=10)
    quality_gate_max_iterations: int = Field(default=2, ge=1, le=10)

    # --- Safety ------------------------------------------------------------
    # File operations are confined to target_repo_path. Extensions an agent is
    # permitted to write, to reduce blast radius.
    writable_extensions: tuple[str, ...] = Field(
        default=(".py", ".ts", ".tsx", ".js", ".jsx", ".md", ".json", ".yaml", ".yml", ".txt", ".css"),
    )

    @property
    def conventions_path(self) -> Path:
        return self.target_repo_path / self.conventions_filename


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance (read env once per process)."""
    return Settings()  # type: ignore[call-arg]
