from __future__ import annotations

from jira_to_pr.config.settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]
