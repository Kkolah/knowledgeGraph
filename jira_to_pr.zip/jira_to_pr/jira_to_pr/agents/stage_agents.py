from __future__ import annotations

"""Individual stage agents.

Each agent reads only the state keys it needs (via {key} templating in its
instruction) and is granted only the tools its role requires. This least-
privilege, least-context discipline is what keeps the pipeline debuggable and
prevents an agent from acting outside its lane.
"""

from google.adk.agents.llm_agent import LlmAgent

from jira_to_pr.agents import prompts
from jira_to_pr.config.settings import get_settings
from jira_to_pr.tools.flow_tools import clear_blockers, exit_loop, record_blocker
from jira_to_pr.tools.repo_tools import (
    list_repo_files,
    read_repo_conventions,
    read_repo_file,
    run_checks,
    write_repo_file,
)

_MODEL = get_settings().model


def build_spec_agent() -> LlmAgent:
    return LlmAgent(
        name="spec_agent",
        model=_MODEL,
        description="Turns a raw Jira ticket into a testable specification.",
        instruction=prompts.SPEC_INSTRUCTION,
        output_key="spec",
    )


def build_design_agent() -> LlmAgent:
    return LlmAgent(
        name="design_agent",
        model=_MODEL,
        description="Designs the change to fit the existing repository.",
        instruction=prompts.DESIGN_INSTRUCTION,
        tools=[read_repo_conventions, list_repo_files, read_repo_file],
        output_key="design",
    )


def build_dev_agent() -> LlmAgent:
    return LlmAgent(
        name="dev_agent",
        model=_MODEL,
        description="Implements the design, writing code into the repo.",
        instruction=prompts.DEV_INSTRUCTION,
        tools=[
            read_repo_conventions,
            list_repo_files,
            read_repo_file,
            write_repo_file,
            run_checks,
            clear_blockers,
        ],
        output_key="dev_output",
    )


def build_qa_agent() -> LlmAgent:
    return LlmAgent(
        name="qa_agent",
        model=_MODEL,
        description="Writes/runs tests against the spec; exits loop when green.",
        instruction=prompts.QA_INSTRUCTION,
        tools=[list_repo_files, read_repo_file, write_repo_file, run_checks, exit_loop],
        output_key="qa_report",
    )


def build_review_agent() -> LlmAgent:
    return LlmAgent(
        name="review_agent",
        model=_MODEL,
        description="Senior code review against design and conventions.",
        instruction=prompts.REVIEW_INSTRUCTION,
        tools=[read_repo_file, record_blocker],
        output_key="review",
    )


def build_security_agent() -> LlmAgent:
    return LlmAgent(
        name="security_agent",
        model=_MODEL,
        description="Threat-reviews the change (findings only).",
        instruction=prompts.SECURITY_INSTRUCTION,
        tools=[read_repo_file, record_blocker],
        output_key="security",
    )


def build_performance_agent() -> LlmAgent:
    return LlmAgent(
        name="performance_agent",
        model=_MODEL,
        description="Flags performance risks in the change.",
        instruction=prompts.PERFORMANCE_INSTRUCTION,
        tools=[read_repo_file, record_blocker],
        output_key="perf",
    )


def build_quality_gate_agent() -> LlmAgent:
    return LlmAgent(
        name="quality_gate_agent",
        model=_MODEL,
        description="Releases the pipeline only when no blockers remain.",
        instruction=prompts.QUALITY_GATE_INSTRUCTION,
        tools=[exit_loop],
        output_key="quality_gate",
    )


def build_docs_agent() -> LlmAgent:
    return LlmAgent(
        name="docs_agent",
        model=_MODEL,
        description="Updates docs to match the change.",
        instruction=prompts.DOCS_INSTRUCTION,
        tools=[read_repo_conventions, list_repo_files, read_repo_file, write_repo_file],
        output_key="docs",
    )


def build_pr_agent() -> LlmAgent:
    return LlmAgent(
        name="pr_agent",
        model=_MODEL,
        description="Assembles the PR description; never merges.",
        instruction=prompts.PR_INSTRUCTION,
        output_key="pr_draft",
    )
