from __future__ import annotations

"""Pipeline composition.

The pipeline is split into two runnable roots because of the two human gates:

  Run 1 (spec_root):  spec_agent only -> may pause for human clarification.
  Run 2 (build_root): design -> [Dev/QA loop] -> review -> security ->
                       performance -> [Quality-gate loop] -> docs -> pr_agent
                       -> pauses before human merge.

Loops:
  * DevQALoop: Dev then QA, repeated until QA calls exit_loop or max_iterations.
  * QualityGateLoop: Dev then the quality gate, repeated until no blockers
    remain (gate calls exit_loop) or max_iterations.
"""

from google.adk.agents.llm_agent import LlmAgent
from google.adk.agents.loop_agent import LoopAgent
from google.adk.agents.sequential_agent import SequentialAgent

from jira_to_pr.agents import stage_agents
from jira_to_pr.config.settings import get_settings


def build_spec_root() -> LlmAgent:
    """Run 1 root: just the spec agent (human clarification gate follows)."""
    return stage_agents.build_spec_agent()


def build_build_root() -> SequentialAgent:
    """Run 2 root: the full build pipeline after clarification is resolved."""
    settings = get_settings()

    dev_qa_loop = LoopAgent(
        name="dev_qa_loop",
        description="Iterate Dev->QA until acceptance criteria pass.",
        sub_agents=[
            stage_agents.build_dev_agent(),
            stage_agents.build_qa_agent(),
        ],
        max_iterations=settings.dev_qa_max_iterations,
    )

    # Dev (fix) -> quality gate (re-check blockers), looped.
    quality_gate_loop = LoopAgent(
        name="quality_gate_loop",
        description="Fix blockers from review/security/perf until gate clears.",
        sub_agents=[
            stage_agents.build_dev_agent(),
            stage_agents.build_quality_gate_agent(),
        ],
        max_iterations=settings.quality_gate_max_iterations,
    )

    return SequentialAgent(
        name="build_pipeline",
        description="Design through PR-draft for one Jira ticket.",
        sub_agents=[
            stage_agents.build_design_agent(),
            dev_qa_loop,
            stage_agents.build_review_agent(),
            stage_agents.build_security_agent(),
            stage_agents.build_performance_agent(),
            quality_gate_loop,
            stage_agents.build_docs_agent(),
            stage_agents.build_pr_agent(),
        ],
    )


# ADK's `adk web` / `adk run` discover a module-level `root_agent`. We expose the
# full build pipeline by default; Run 1 (spec) is driven explicitly via the CLI
# in pipeline_runner.py to honor the clarification gate.
root_agent = build_build_root()
