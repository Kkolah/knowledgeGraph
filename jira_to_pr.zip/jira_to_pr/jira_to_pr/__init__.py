from __future__ import annotations

"""Jira-to-PR: a Google ADK multi-agent pipeline that turns a Jira ticket into
a production-ready pull request."""

__version__ = "0.1.0"
