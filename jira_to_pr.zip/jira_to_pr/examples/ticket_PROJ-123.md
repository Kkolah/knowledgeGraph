# PROJ-123: Add a "Recently Viewed Products" component

## Description
Users want to quickly return to products they looked at earlier in their
session. Add a "Recently Viewed" component to the product detail page that
shows the last 5 distinct products the user viewed, most recent first.

## Notes
- Should not show the product currently being viewed.
- Persist across page navigations within a session.
- Match the existing card styling used elsewhere on the site.
