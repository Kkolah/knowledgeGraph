1. Persistence: session only (clear on logout / browser close). No backend storage.
2. Empty state: hide the component entirely when there are no other viewed products.
3. Max items: exactly 5; evict oldest beyond that.
