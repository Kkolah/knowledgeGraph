# Repository conventions (template)

> Place this file at the root of the **target repository** (the codebase your
> Jira tickets modify), not in the pipeline repo. The Design, Dev, QA, Review,
> Security, Refactor, and Docs agents read it via the `read_repo_conventions`
> tool to generate code that matches your existing patterns. Fill every section
> with your real rules and a short example. The richer this file, the less the
> agents improvise.

## Architecture overview
- High-level shape (e.g. layered, hexagonal, feature-sliced).
- Where each kind of thing lives. Example:
  - UI components: `src/components/<ComponentName>/`
  - Business logic: `src/services/`
  - Data access: `src/repositories/`
  - Tests: co-located as `*.test.ts` next to the file under test.

## Naming conventions
- Files: `PascalCase` for components, `camelCase` for utilities.
- Functions: `camelCase`; classes: `PascalCase`; constants: `UPPER_SNAKE`.
- Test files mirror the source filename with a `.test` suffix.

## Logging
- Library: e.g. `structlog` (Python) / `pino` (Node).
- Required: log at INFO on entry to public service methods; ERROR with the
  exception on caught failures; never log secrets or full request bodies.
- Format example:
  ```python
  logger.info("create_order.start", user_id=user_id, item_count=len(items))
  ```

## Error handling
- Raise/throw typed errors (e.g. `DomainError` subclasses), never bare strings.
- Validate inputs at the boundary; assume internal callers pass valid data.
- User-facing errors return the project's standard error envelope.

## State / data management (frontend)
- e.g. Redux Toolkit slices in `src/store/`; no direct context for shared state.
- Session-scoped data uses `sessionStorage` via the `useSession` hook.

## Dependency injection / wiring
- e.g. Constructor injection; providers registered in `src/container.ts`.

## Testing
- Framework: e.g. `pytest` / `vitest` + Testing Library.
- Command the QA agent should run: e.g. `pytest -q` or `npm test`.
- Every new public behavior needs a test mapped to an acceptance criterion.

## Lint / format
- Command the Dev agent should run before finishing: e.g. `ruff check .` /
  `npm run lint`.

## Documentation
- Where docs live (e.g. `docs/`), the format (Markdown), and whether a
  changelog entry is required per change.

## Hard rules ("always / never")
- Always: <your non-negotiables>.
- Never: <patterns the team has banned and why>.
