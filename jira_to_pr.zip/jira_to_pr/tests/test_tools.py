from __future__ import annotations

"""Tests for the safety-critical tool layer. These run without an LLM.

They verify the sandbox (no path traversal, extension allowlist) and the
state-mutating flow tools, which are the parts most likely to cause real damage
if wrong.
"""

from pathlib import Path

import pytest


@pytest.fixture
def repo(tmp_path, monkeypatch):
    """A temporary target repo + fresh cached settings pointing at it."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "example.py").write_text("print('hi')\n")
    (tmp_path / "AGENTS.md").write_text("# Conventions\nUse structlog.\n")
    monkeypatch.setenv("J2PR_TARGET_REPO_PATH", str(tmp_path))
    # Clear the lru_cache so the new env is picked up.
    from jira_to_pr.config import settings as settings_mod

    settings_mod.get_settings.cache_clear()
    return tmp_path


class _FakeToolContext:
    """Minimal stand-in for ADK's ToolContext (state + actions)."""

    def __init__(self):
        self.state: dict = {}

        class _Actions:
            escalate = False

        self.actions = _Actions()


def test_read_conventions_found(repo):
    from jira_to_pr.tools.repo_tools import read_repo_conventions

    out = read_repo_conventions(_FakeToolContext())
    assert out["found"] is True
    assert "structlog" in out["conventions"]


def test_read_conventions_missing(repo):
    from jira_to_pr.tools.repo_tools import read_repo_conventions

    (repo / "AGENTS.md").unlink()
    out = read_repo_conventions(_FakeToolContext())
    assert out["found"] is False


def test_list_files(repo):
    from jira_to_pr.tools.repo_tools import list_repo_files

    out = list_repo_files(_FakeToolContext(), ".")
    assert "src/example.py" in out["files"]


def test_path_traversal_rejected(repo):
    from jira_to_pr.tools.repo_tools import read_repo_file

    # _safe_path raises ValueError before touching the filesystem; agents
    # surface this as a tool error.
    with pytest.raises(ValueError):
        read_repo_file(_FakeToolContext(), "../../etc/passwd")


def test_absolute_path_rejected(repo):
    from jira_to_pr.tools.repo_tools import read_repo_file

    with pytest.raises(ValueError):
        read_repo_file(_FakeToolContext(), "/etc/passwd")


def test_write_extension_allowlist(repo):
    from jira_to_pr.tools.repo_tools import write_repo_file

    ctx = _FakeToolContext()
    blocked = write_repo_file(ctx, "evil.sh", "rm -rf /")
    assert blocked["written"] is False
    allowed = write_repo_file(ctx, "src/new.py", "x = 1\n")
    assert allowed["written"] is True
    assert "src/new.py" in ctx.state["touched_files"]


def test_exit_loop_sets_escalate(repo):
    from jira_to_pr.tools.flow_tools import exit_loop

    ctx = _FakeToolContext()
    out = exit_loop(ctx)
    assert ctx.actions.escalate is True
    assert out["status"] == "exiting_loop"


def test_blocker_lifecycle(repo):
    from jira_to_pr.tools.flow_tools import clear_blockers, record_blocker

    ctx = _FakeToolContext()
    record_blocker(ctx, "security", "SQL injection in login")
    assert len(ctx.state["open_blockers"]) == 1
    clear_blockers(ctx)
    assert ctx.state["open_blockers"] == []
