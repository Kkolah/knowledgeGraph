"""
Symbolic Regression example using gplearn.

Goal: given the CSV (x, y, z, a, b, c, d, r), automatically discover
that r = (x + y) / z, while ignoring the irrelevant decoy variables
a, b, c, d.

Setup (run once in your terminal):
    pip install gplearn pandas numpy

Then just run this file:
    python symbolic_regression_gplearn.py
"""

import pandas as pd
from gplearn.genetic import SymbolicRegressor

# --- 1. Load data ---
DATA_PATH = "symbolic_regression_data.csv"  # put the CSV in the same folder, or use a full path
df = pd.read_csv(DATA_PATH)

feature_names = ["x", "y", "z", "a", "b", "c", "d"]
X = df[feature_names].values
y = df["r"].values

# --- 2. Configure the symbolic regressor ---
est = SymbolicRegressor(
    population_size=2000,      # how many candidate formulas per generation
    generations=25,            # how many generations to evolve
    function_set=("add", "sub", "mul", "div"),  # allowed operators
    metric="mse",              # fitness = mean squared error vs actual r
    parsimony_coefficient=0.001,  # penalty for overly complex formulas
    random_state=0,
    verbose=1,                 # prints generation-by-generation progress
)

# --- 3. Run the search ---
est.fit(X, y)

# --- 4. Show the winning formula ---
print()
print("Best program found (in X0..X6 = x,y,z,a,b,c,d order):")
print(est._program)

# --- 5. Sanity check: predict vs actual on a few rows ---
preds = est.predict(X[:5])
print()
print("Sample predictions vs actual r:")
for p, actual in zip(preds, y[:5]):
    print(f"  predicted={p:.4f}   actual={actual:.4f}")
